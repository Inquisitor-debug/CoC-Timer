package com.example.cocwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.concurrent.TimeUnit

class CocWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("coc_widget", Context.MODE_PRIVATE)
        when (intent.action) {
            "com.example.cocwidget.NEXT_PROFILE" -> prefs.edit().putInt("profile", (prefs.getInt("profile", 1) % 4) + 1).apply()
            "com.example.cocwidget.START_BUILD" -> prefs.edit().putLong("build_${prefs.getInt("profile",1)}", System.currentTimeMillis() + TimeUnit.DAYS.toMillis(1)).apply()
            "com.example.cocwidget.START_LAB" -> prefs.edit().putLong("lab_${prefs.getInt("profile",1)}", System.currentTimeMillis() + TimeUnit.DAYS.toMillis(1)).apply()
        }
        super.onReceive(context, intent)
        if (intent.action != null) updateAll(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { ids.forEach { update(context, manager, it) } }

    private fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        manager.getAppWidgetIds(ComponentName(context, CocWidgetProvider::class.java)).forEach { update(context, manager, it) }
    }

    private fun update(context: Context, manager: AppWidgetManager, id: Int) {
        val p = context.getSharedPreferences("coc_widget", Context.MODE_PRIVATE)
        val profile = p.getInt("profile", 1)
        val views = RemoteViews(context.packageName, R.layout.coc_widget)
        views.setTextViewText(R.id.profile, "Профиль $profile")
        views.setTextViewText(R.id.buildTimer, remaining(p.getLong("build_$profile", 0L)))
        views.setTextViewText(R.id.labTimer, remaining(p.getLong("lab_$profile", 0L)))
        views.setOnClickPendingIntent(R.id.next, action(context, "com.example.cocwidget.NEXT_PROFILE", 1))
        views.setOnClickPendingIntent(R.id.buildButton, action(context, "com.example.cocwidget.START_BUILD", 2))
        views.setOnClickPendingIntent(R.id.labButton, action(context, "com.example.cocwidget.START_LAB", 3))
        manager.updateAppWidget(id, views)
    }

    private fun action(context: Context, name: String, request: Int): PendingIntent {
        val i = Intent(context, CocWidgetProvider::class.java).setAction(name)
        return PendingIntent.getBroadcast(context, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun remaining(end: Long): String {
        if (end == 0L) return "Не задано"
        val ms = end - System.currentTimeMillis()
        if (ms <= 0) return "✅ Готово"
        val hours = TimeUnit.MILLISECONDS.toHours(ms)
        val days = hours / 24
        val remHours = hours % 24
        val mins = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
        return if (days > 0) "${days}д ${remHours}ч ${mins}м" else "${hours}ч ${mins}м"
    }
}
